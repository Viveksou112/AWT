a=10;
function j(){
    console.log("hello");
    console.log(a);
}
j();
