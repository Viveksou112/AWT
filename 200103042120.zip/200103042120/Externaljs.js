function external(){
   alert("this is external js");
}
function externalConfirm(){
    confirm("this is external confirm");
    if(true){
        alert("done");
    }
    else{
    }
}
function externalPrompt(){
    // let a= prompt("enter name:"); // manually
    document.getElementById("pe").innerHTML=a; // by funxtion
        console.log("hi"+a);
    alert("your name is"+a);
 }
 a;
function j(){
    console.log("hello");
    console.log(a);
}
j();
var a=10;

